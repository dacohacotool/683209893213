class Quan_ly_cau_Hinh_gui:
    def trang_add_config (self):
        global data
        panel = Panel("""[bold white] Dùng phím mũi tênn hoặc wasd để di chuyển tuỳ chọn\n\
[bold white] Enter để chọn\n\
""", title="SHORT KEYS", border_style="cyan")
        console.print (panel)
        list_chon =[]
        for name_st, value in data['ds_cau_hinh'].items():
            list_chon.append ({'text':f'[bold red][[bold yellow]{name_st}[/bold yellow]][/bold red] [bold white] Config đã tạo...',
    "chon":name_st})
        list_chon.append ({'text':f'[bold red][[bold yellow]ADD_CONFIG[/bold yellow]][/bold red] [bold white]Thêm Config mới',
    "chon":'m4e38rjjsjmr832jj'})
        print (f'{whiteb}Danh sách Config đã tạo')
        lua_chon = load_list_chon (list_chon,clear=False,in_help=False)
        if (lua_chon == 'p'):
            return main ()
        elif (lua_chon == 'm4e38rjjsjmr832jj'):
            mame_config_moi = input (f'{yellowb}Đặt tên cho config mới: {whiteb}').lower()
            data['ds_cau_hinh'][mame_config_moi] = self.get_cau_hinh_mat_dinh()
            self.load_va_edit_config (mame_config_moi)
        else:
            self.load_va_edit_config (lua_chon)
    def get_table_config (self,name_config):
        global data
        data_can_su = data['ds_cau_hinh'].get (name_config)
        #table
        table_jobs =  Table(title="[bold bright_yellow]Cấu Hình Jobs", box=box.DOUBLE, style="#ffc033",show_lines=True)
        list_hien_thi = {
            'Name Jobs':[True,{'justify':'center','style':'#339eff','width':None,'no_wrap':True}],
            'Value':[True,{'justify':'center','style':'#339eff','width':None,'no_wrap':True}],
            }
        for name,value in list_hien_thi.items():
            if (value[0] == True):
                table_jobs.add_column(f"[bold white]{name}", justify=value[1]['justify'], style=value[1]['style'],width=value[1]['width'],no_wrap=value[1]['no_wrap'],overflow="ellipsis")
        for name,value in data_can_su.get('jobs').items():
            if (value == True):
                value=f'[bold green]True'
            else:
                value=f'[bold red]False'
            table_jobs.add_row(f'{name}', f'{value}')
        # table
        table_delay_lam_nhiem_vu_thanh_cong =  Table(title="[bold bright_yellow]Delay làm nhiệm vụ nếu thành công", box=box.DOUBLE, style="#8233ff",show_lines=True)
        list_hien_thi = {
            'Name Delay':[True,{'justify':'center','style':'#339eff','width':None,'no_wrap':True}],
            'Value Min':[True,{'justify':'center','style':'#97ff33','width':None,'no_wrap':True}],
            'Value Max':[True,{'justify':'center','style':'#ffd233','width':None,'no_wrap':True}],
            }
        for name,value in list_hien_thi.items():
            if (value[0] == True):
                table_delay_lam_nhiem_vu_thanh_cong.add_column(f"[bold white]{name}", justify=value[1]['justify'], style=value[1]['style'],width=value[1]['width'],no_wrap=value[1]['no_wrap'],overflow="ellipsis")
        for name,value in data_can_su['delay'].get('delay_lam_nhiem_vu').get ('thanh_cong').items():
            table_delay_lam_nhiem_vu_thanh_cong.add_row(f'{name}', f'{value["min"]}', f'{value["max"]}')
        # table
        table_delay_lam_nhiem_vu_that_bai =  Table(title="[bold bright_yellow]Delay làm nhiệm vụ nếu thát bại", box=box.DOUBLE, style="#8233ff",show_lines=True)
        list_hien_thi = {
            'Name Delay':[True,{'justify':'center','style':'#339eff','width':None,'no_wrap':True}],
            'Value Min':[True,{'justify':'center','style':'#97ff33','width':None,'no_wrap':True}],
            'Value Max':[True,{'justify':'center','style':'#ffd233','width':None,'no_wrap':True}],
            }
        for name,value in list_hien_thi.items():
            if (value[0] == True):
                table_delay_lam_nhiem_vu_that_bai.add_column(f"[bold white]{name}", justify=value[1]['justify'], style=value[1]['style'],width=value[1]['width'],no_wrap=value[1]['no_wrap'],overflow="ellipsis")
        for name,value in data_can_su['delay'].get('delay_lam_nhiem_vu').get ('that_bai').items():
            table_delay_lam_nhiem_vu_that_bai.add_row(f'{name}', f'{value["min"]}', f'{value["max"]}')
        pannel_delay_lam_nhiem_vu = Panel(Group(table_delay_lam_nhiem_vu_thanh_cong,table_delay_lam_nhiem_vu_that_bai), title="Cấu hình delay làm jobs", border_style="#C92300", width=50)
        # table
        table_delay_chong_block =  Table(title="[bold bright_yellow]Làm Số Jobs thì delay", box=box.DOUBLE, style="#767570",show_lines=True)
        list_hien_thi = {
            'Name Delay':[True,{'justify':'center','style':'#ffdd00','width':None,'no_wrap':True}],
            'Value Min':[True,{'justify':'center','style':'#97ff33','width':None,'no_wrap':True}],
            'Value Max':[True,{'justify':'center','style':'#ffd233','width':None,'no_wrap':True}],
            }
        for name,value in list_hien_thi.items():
            if (value[0] == True):
                table_delay_chong_block.add_column(f"[bold white]{name}", justify=value[1]['justify'], style=value[1]['style'],width=value[1]['width'],no_wrap=value[1]['no_wrap'],overflow="ellipsis")
        for name,value in data_can_su['delay']['chong_block'].get('lam_so_jobs_thi_delay').items():
            try:
                table_delay_chong_block.add_row(f'{name}', f'{value["min"]}', f'{value["max"]}')
            except:pass
        text = (f"[#ffdd00]Thời gian delay:[/][#97ff33] {data_can_su['delay']['chong_block']['so_giay_dung']}s")
        panel_delay_chong_block = Panel(Group(table_delay_chong_block,text), title="Cấu hình chống block", border_style="#ffffff", width=50)
        #doi acc
        table_delay_doi_Acc =  Table(title="[bold bright_yellow]Cấu hình Đổi Acc", box=box.DOUBLE, style="#e900ff",show_lines=True)
        list_hien_thi = {
            'Name Delay':[True,{'justify':'center','style':'bold #ffffff','width':None,'no_wrap':True}],
            'Đạt Tổng Số Jobs Thành công':[True,{'justify':'center','style':'#97ff33','width':None,'no_wrap':True}],
            'Đạt Tổng Số Jobs Lỗi':[True,{'justify':'center','style':'#ffd233','width':None,'no_wrap':True}],
            }
        for name,value in list_hien_thi.items():
            if (value[0] == True):
                table_delay_doi_Acc.add_column(f"[bold white]{name}", justify=value[1]['justify'], style=value[1]['style'],width=value[1]['width'],no_wrap=value[1]['no_wrap'],overflow="ellipsis")
        for name,value in data_can_su['delay']['doi_acc'].get('dat_tong_so_jobs_thanh_cong').items():
                table_delay_doi_Acc.add_row(f'{name}', f'{ data_can_su['delay']['doi_acc']["dat_tong_so_jobs_thanh_cong"][name]}', f'{ data_can_su['delay']['doi_acc']["dat_tong_so_jobs_loi"][name]}')
        
        text = (f"[#ffffff]Số giây chạy được đạt: [#97ff33]{data_can_su['delay']['doi_acc']['chay_duoc_so_giay']}s\n\
[#ffffff]Số xu đã nhận: [#97ff33]{data_can_su['delay']['doi_acc']['so_xu_kiem_dat']}")
        panel_delay_doi_acc = Panel(Group(table_delay_doi_Acc,text), title="Cấu hình đổi acc", border_style="#e900ff", width=80)
        #dung acc
        table_delay_dung_chay =  Table(title="[bold bright_yellow]Cấu hình Dừng chạy Acc", box=box.DOUBLE, style="#8aff3c",show_lines=True)
        list_hien_thi = {
            'Name Delay':[True,{'justify':'center','style':'#ffffff','width':None,'no_wrap':True}],
            'Đạt Tổng Số Jobs Thành công':[True,{'justify':'center','style':'#97ff33','width':None,'no_wrap':True}],
            'Đạt Tổng Số Jobs Lỗi':[True,{'justify':'center','style':'#ffd233','width':None,'no_wrap':True}],
            }
        for name,value in list_hien_thi.items():
            if (value[0] == True):
                table_delay_dung_chay.add_column(f"[bold white]{name}", justify=value[1]['justify'], style=value[1]['style'],width=value[1]['width'],no_wrap=value[1]['no_wrap'],overflow="ellipsis")
        for name,value in data_can_su['delay']['dung_chay'].get('dat_tong_so_jobs_thanh_cong').items():
                table_delay_dung_chay.add_row(f'{name}', f'{ data_can_su['delay']['dung_chay']["dat_tong_so_jobs_thanh_cong"][name]}', f'{ data_can_su['delay']['dung_chay']["dat_tong_so_jobs_loi"][name]}')
        text = (f"[#ffffff]Số giây chạy được đạt: [#97ff33]{data_can_su['delay']['dung_chay']['chay_duoc_so_giay']}s\n\
[#ffffff]Số xu đã nhận: [#97ff33]{data_can_su['delay']['dung_chay']['so_xu_kiem_dat']}\n\
[#ffffff]Số Tổng số xu của tài khoản đạt: [#97ff33]{data_can_su['delay']['dung_chay']['tong_xu_dat']}")
        panel_delay_dung_chay = Panel(Group(table_delay_dung_chay,text), title="Cấu hình dừng chạy acc", border_style="#8aff3c", width=80)

        columns = Columns([table_jobs,pannel_delay_lam_nhiem_vu,panel_delay_chong_block,panel_delay_doi_acc,panel_delay_dung_chay] ,  expand=True, equal=False, padding=0,column_first =True)  

        panel = Panel(
            columns,  # Nội dung columns
            title=f"Config {name_config}",  # Tiêu đề của panel
            border_style="bold yellow",  # Tùy chỉnh màu viền
            width=400  # Chiều rộng của panel
        )
        return panel

        
    def load_va_edit_config (self,name_config):
        global data
        clean_bar ()
        tablee = self.get_table_config(name_config)
        panel = Panel("""[bold red][[bold yellow]1[/bold yellow]][/bold red] [bold white] Để chỉnh cấu hình jobs\n\
[bold red][[bold yellow]2[/bold yellow]][/bold red] [bold white] Để chỉnh delay làm nhiệm vụ\n\
[bold red][[bold yellow]3[/bold yellow]][/bold red] [bold white] Để chỉnh delay chống block\n\
[bold red][[bold yellow]4[/bold yellow]][/bold red] [bold white] Để chỉnh delay đổi acc\n\
[bold red][[bold yellow]5[/bold yellow]][/bold red] [bold white] Để chỉnh delay dừng acc\n\
[bold red][[bold yellow]p[/bold yellow]][/bold red] [bold white] Để thoát\n\
""", title="SHORT KEYS", border_style="cyan", width=200)
        console.print (tablee)
        console.print (panel)
        data_can_su = data['ds_cau_hinh'].get (name_config)
        mauu_ngau_nhien = randommau()
        
        while True:
            chon_input= getch ()
            if (giao_dien_terminal().check_key (chon_input, '1')):
                for name,value in data_can_su.get('jobs').items():
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    data_can_su['jobs'][name]= input (f'{yellowb}Bạn có muốn làm nhiệm vụ {name}? (Y/N):{whiteb}').strip().lower() == 'y'
                break
            elif (giao_dien_terminal().check_key (chon_input, '2')):
                list_chon_dl=[]
                list_chon_dl.append ({'text':f'[bold red][[bold yellow]thanh_cong[/bold yellow]][/bold red] [bold white]Chỉnh delay khi làm jobs thành công',
    "chon":'thanh_cong'})
                list_chon_dl.append ({'text':f'[bold red][[bold yellow]that_bai[/bold yellow]][/bold red] [bold white]Chỉnh delay khi làm jobs thất bại',
    "chon":'that_bai'})
                print (f'{whiteb}Chọn tuỳ chỉnh')
                lua_chon = load_list_chon (list_chon_dl,clear=False,in_help=False)
                if (giao_dien_terminal().check_key (lua_chon, 'p')):return main ()
                elif (giao_dien_terminal().check_key (lua_chon, 'h')):return main ()
                for name,value in data_can_su['delay'].get('delay_lam_nhiem_vu').get (lua_chon).items():
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    while True:
                        try:
                            data_can_su['delay']['delay_lam_nhiem_vu'][lua_chon][name]['min']= int (input (f'{yellowb}Nhập Delay {name} Min:{whiteb}').strip().lower())
                            data_can_su['delay']['delay_lam_nhiem_vu'][lua_chon][name]['max']= int (input (f'{yellowb}Nhập Delay {name} Max:{whiteb}').strip().lower())
                            break
                        except:
                            print (f'{redb}Vui lòng chỉ nhập số')
                break
            elif (giao_dien_terminal().check_key (chon_input, '3')):
                for name,value in data_can_su['delay']['chong_block'].get('lam_so_jobs_thi_delay').items():
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    while True:
                        try:
                            data_can_su['delay']['chong_block']['lam_so_jobs_thi_delay'][name]['min']= int (input (f'{yellowb}Làm bao nhiêu jobs {name} thì delay chống block (Min Value) ? :{whiteb}').strip().lower())
                            data_can_su['delay']['chong_block']['lam_so_jobs_thi_delay'][name]['max']= int (input (f'{yellowb}Làm bao nhiêu jobs {name} thì delay chống block (Max Value) ? :{whiteb}').strip().lower())
                            break
                        except:
                            print (f'{redb}Vui lòng chỉ nhập số')
                while True:
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    try:
                        data_can_su['delay']['chong_block']['so_giay_dung'] = int (input (f'{yellowb}Dừng bao nhiêu giây ? :{whiteb}').strip().lower())
                        break
                    except:
                        print (f'{redb}Vui lòng chỉ nhập số')
                break   
            elif (giao_dien_terminal().check_key (chon_input, '4')):
                for name,value in data_can_su['delay']['doi_acc'].get('dat_tong_so_jobs_thanh_cong').items():
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    while True:
                        try:
                            data_can_su['delay']['doi_acc']["dat_tong_so_jobs_thanh_cong"][name]= int (input (f'{yellowb}Đạt tổng bao nhiêu jobs {name} thành công thì đổi acc? :{whiteb}').strip().lower())
                            data_can_su['delay']['doi_acc']['dat_tong_so_jobs_loi'][name]= int (input (f'{yellowb}Làm bao nhiêu jobs {name} lỗi thì đổi acc? :{whiteb}').strip().lower())
                            break
                        except:
                            print (f'{redb}Vui lòng chỉ nhập số')
                while True:
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    try:
                        data_can_su['delay']['doi_acc']['chay_duoc_so_giay'] = int (input (f'{yellowb}Đổi acc khi chạy được số giây? :{whiteb}').strip().lower())
                        break
                    except:
                        print (f'{redb}Vui lòng chỉ nhập số')
                while True:
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    try:
                        data_can_su['delay']['doi_acc']['so_xu_kiem_dat'] = int (input (f'{yellowb}Đổi acc khi kiếm được số xu? :{whiteb}').strip().lower())
                        break
                    except:
                        print (f'{redb}Vui lòng chỉ nhập số')
                break
            elif (giao_dien_terminal().check_key (chon_input, '5')):

                for name,value in data_can_su['delay']['dung_chay'].get('dat_tong_so_jobs_thanh_cong').items():
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    while True:
                        try:
                            data_can_su['delay']['dung_chay']["dat_tong_so_jobs_thanh_cong"][name]= int (input (f'{yellowb}Đạt tổng bao nhiêu jobs {name} thành công thì dừng chạy acc? :{whiteb}').strip().lower())
                            data_can_su['delay']['dung_chay']['dat_tong_so_jobs_loi'][name]= int (input (f'{yellowb}Làm bao nhiêu jobs {name} lỗi thì dừng chạy acc? :{whiteb}').strip().lower())
                            break
                        except:
                            print (f'{redb}Vui lòng chỉ nhập số')
                while True:
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    try:
                        data_can_su['delay']['dung_chay']['chay_duoc_so_giay']= int (input (f'{yellowb}Dừng chạy acc acc khi chạy được số giây? :{whiteb}').strip().lower())
                        break
                    except:
                        print (f'{redb}Vui lòng chỉ nhập số')
                while True:
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    try:
                        data_can_su['delay']['dung_chay']['so_xu_kiem_dat'] = int (input (f'{yellowb}Dừng chạy acc khi kiếm được số xu? :{whiteb}').strip().lower())
                        break
                    except:
                        print (f'{redb}Vui lòng chỉ nhập số')
                while True:
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    try:
                        data_can_su['delay']['dung_chay']['tong_xu_dat']= int (input (f'{yellowb}Dừng chạy acc khi tổng xu đạt? :{whiteb}').strip().lower())
                        break
                    except:
                        print (f'{redb}Vui lòng chỉ nhập số')
                break
            elif (giao_dien_terminal().check_key (chon_input, 'p')):return main ()
            elif (giao_dien_terminal().check_key (chon_input, 'h')):return main ()
            
        data['ds_cau_hinh'][name_config]= data_can_su
        return self.load_va_edit_config (name_config)