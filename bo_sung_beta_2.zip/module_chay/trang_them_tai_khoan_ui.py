class trang_them_tai_khoan_ui:
    def them_tai_khoan_ui (self):
        global data
        list_chon = [
            {'text':f'[bold red][[bold yellow]ADD_1[/bold yellow]][/bold red] [bold white] Thêm 1 tài khoản',
            "chon":'add_1'},
            {'text':f'[bold red][[bold yellow]ADD_2[/bold yellow]][/bold red] [bold white] Thêm tài khoản hàng loại bằng file',
            "chon":'add_2'},
            {'text':f'[bold red][[bold yellow]HOME[/bold yellow]][/bold red] [bold white] Quay lại Home',
            "chon":'home'},
            ]
        lua_chon = load_list_chon (list_chon)
        if (lua_chon == 'p'):
            return main ()
        elif (lua_chon == 'home'):
            return main ()
        elif (lua_chon == 'add_1'):
            data_them= {}
            clean_bar()
            while True:
                mauu_ngau_nhien = randommau()
                print (f'{mauu_ngau_nhien}{thanhngang}')
                list_chon = [
                        {'text':f'[bold red][[bold yellow]0[/bold yellow]][/bold red] [bold white] Tài khoản Golike',
                        "chon":'golike'},
                        {'text':f'[bold red][[bold yellow]1[/bold yellow]][/bold red] [bold white] Tài khoản TraoDoisub',
                        "chon":'tds'},
                        {'text':f'[bold red][[bold yellow]2[/bold yellow]][/bold red] [bold white] Back',
                        "chon":'2'},
                        ]
                lua_chon = load_list_chon (list_chon,clear=True,in_help=False)
                if (lua_chon == 'golike'):
                    
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    print (f'{yellowb}{icon1}{whiteb} Nhập authorization golike{lightblueb}: ', end= '')
                    data_them['authorization'] = input ('')
                    if (data_them['authorization'] == 'p'):
                        return main ()
                    data_them['proxy_g']= ''
                    check_proxxy_Golike = check_proxy (data_them['proxy_g'])
                    if (check_proxxy_Golike['trangthai'] == 'live'):
                        trang_thai_proxy_g=True
                    elif (check_proxxy_Golike['trangthai'] == 'die'):
                        trang_thai_proxy_g=False
                        print (f'{redb}Proxy Die')
                        continue
                    else:
                        trang_thai_proxy_g=False
                    golike_in_module = Golike_Module (type_jobs='',account_id='',athor=data_them['authorization'],req = curl_module(data_them['proxy_g']))
                    data_them['username_golike'] =golike_in_module.get_username_golike()
                    if (data_them['username_golike']== False):
                        print (f'{redb}Athor sai hoặc không tồn lại !!!')
                        continue
                    clean_bar()
                    #acc chay
                    json_acc_chay = self.get_data_account_chay_mat_dinh ()
                    json_acc_chay['username'] = data_them["username_golike"]
                    json_acc_chay['proxy'] =data_them['proxy_g']
                    json_acc_chay['authorization'] =data_them['authorization']
                    #them
                    data_golike_cu = data.get ('golike', {})
                    data_golike_cu[json_acc_chay['username']] = json_acc_chay
                    data['golike'] = data_golike_cu
                    ####
                    mauu_ngau_nhien = randommau()
                    while True:
                        print (f'{whiteb}Tài khoản Golike: {yellowb}{data_them["username_golike"]}')
                        print (f'{mauu_ngau_nhien}{thanhngang}')
                        list_chon = [
                            {'text':f'[bold red][[bold yellow]0[/bold yellow]][/bold red] [bold white] Facebook',
                            "chon":'0'},
                            {'text':f'[bold red][[bold yellow]1[/bold yellow]][/bold red] [bold white] ...',
                            "chon":'1'},
                            {'text':f'[bold red][[bold yellow]2[/bold yellow]][/bold red] [bold white] Back',
                            "chon":'2'},
                            ]
                        lua_chon = load_list_chon (list_chon,clear=False,in_help=False)
                        print (f'{mauu_ngau_nhien}{thanhngang}')
                        
                        if (lua_chon == '0'):
                            print (f'{yellowb}{icon1}{whiteb} Nhập Cookie Facebook tài khoản{lightblueb}: ', end= '')
                            data_them['cookie_fb'] = input ('')
                            data_them['proxy_f']= ''
                            check_proxxy_ = check_proxy (data_them['proxy_f'])
                            if (check_proxxy_['trangthai'] == 'live'):
                                trang_thai_proxy_a =True
                            elif (check_proxxy_['trangthai'] == 'die'):
                                trang_thai_proxy_a=False
                                print (f'{redb}Proxy Die')
                                continue
                            requests_session=check_proxxy_['session']
                            fb_tools = facebook_tools_requests(cookie =data_them['cookie_fb'] , req= requests_session )
                            thong_tin= fb_tools.get_thongtin()
                            if (thong_tin.get ('trangthai', False)):
                                uid_a = thong_tin.get ('id', 0)
                                username_a  = thong_tin.get ('username', 'null')
                                name_a  = thong_tin.get ('name', 0)
                                print (f'{greenb}Thêm thành công')
                                #
                                json_them_md = self.get_data_account_mat_dinh()
                                json_them_md['account']['loai_tai_khoan'] = 'facebook'
                                json_them_md['account']['thong_tin'] = {'name':name_a,'uid':uid_a,'username':username_a,'password':'','2fa':'','cookie':data_them['cookie_fb'],
                                                                        'token':'','proxy':data_them['proxy_f'],
                                                                        'email':{'email':'','pass_email':''}}
                                json_them_md['more']['name_account_chay'] =  data_them["username_golike"]
                                json_them_md['more']['name_cau_hinh_chay'] = 'delay_mat_dinh'
                                json_them_md['more']['type_chay'] = 'golike'
                                data_cu = data.get ('list_acc',{})
                                data_cu[json_them_md['name_random']] = json_them_md
                                data['list_acc'] = data_cu
                            else:
                                print (f'{redb}Cookie die hoặc không lấy được thông tin cookie.')
                        elif (lua_chon == 'p'):
                            return main ()
                        elif (lua_chon == '2'):
                            break
                        print (f'{mauu_ngau_nhien}{thanhngang}')#
                elif (lua_chon == 'tds'):
                    mauu_ngau_nhien = randommau()
                    print (f'{mauu_ngau_nhien}{thanhngang}')
                    print (f'{yellowb}{icon1}{whiteb} Nhập Token TDS{lightblueb}: ', end= '')
                    data_them['token'] = input ('')
                    if (data_them['token'] == 'p'):
                        return main ()
                    data_them['proxy_g']= ''
                    check_proxxy_Golike = check_proxy (data_them['proxy_g'])
                    if (check_proxxy_Golike['trangthai'] == 'live'):
                        trang_thai_proxy_g=True
                    elif (check_proxxy_Golike['trangthai'] == 'die'):
                        trang_thai_proxy_g=False
                        print (f'{redb}Proxy Die')
                        continue
                    else:
                        trang_thai_proxy_g=False
                    tds_module =TDS_MODULE_V2 (token =data_them['token'], req=check_proxxy_Golike['session'])
                    check_i=tds_module.get_username()
                    if (check_i['trangthai']== False):
                        print (f'{redb}token sai hoặc không tồn lại !!!')
                        continue
                    clean_bar()
                    #acc chay
                    json_acc_chay = self.get_data_account_chay_mat_dinh ()
                    json_acc_chay['username'] = check_i['username']
                    json_acc_chay['coin'] = check_i['coin']
                    json_acc_chay['proxy'] =data_them['proxy_g']
                    json_acc_chay['token'] =data_them['token']
                    #them
                    data_golike_cu = data.get ('tds', {})
                    data_golike_cu[json_acc_chay['username']] = json_acc_chay
                    data['tds'] = data_golike_cu
                    ####
                    mauu_ngau_nhien = randommau()
                    while True:
                        print (f'{whiteb}Tài khoản TDS: {yellowb}{check_i['username']}')
                        print (f'{mauu_ngau_nhien}{thanhngang}')
                        list_chon = [
                            {'text':f'[bold red][[bold yellow]0[/bold yellow]][/bold red] [bold white] Facebook',
                            "chon":'0'},
                            {'text':f'[bold red][[bold yellow]1[/bold yellow]][/bold red] [bold white] ...',
                            "chon":'1'},
                            {'text':f'[bold red][[bold yellow]2[/bold yellow]][/bold red] [bold white] Back',
                            "chon":'2'},
                            ]
                        lua_chon = load_list_chon (list_chon,clear=False,in_help=False)
                        print (f'{mauu_ngau_nhien}{thanhngang}')
                        
                        if (lua_chon == '0'):
                            print (f'{yellowb}{icon1}{whiteb} Nhập Cookie Facebook tài khoản{lightblueb}: ', end= '')
                            data_them['cookie_fb'] = input ('')
                            data_them['proxy_f']= ''
                            check_proxxy_ = check_proxy (data_them['proxy_f'])
                            if (check_proxxy_['trangthai'] == 'live'):
                                trang_thai_proxy_a =True
                            elif (check_proxxy_['trangthai'] == 'die'):
                                trang_thai_proxy_a=False
                                print (f'{redb}Proxy Die')
                                continue
                            requests_session=check_proxxy_['session']
                            fb_tools = facebook_tools_requests(cookie =data_them['cookie_fb'] , req= requests_session )
                            thong_tin= fb_tools.get_thongtin()
                            if (thong_tin.get ('trangthai', False)):
                                uid_a = thong_tin.get ('id', 0)
                                username_a  = thong_tin.get ('username', 'null')
                                name_a  = thong_tin.get ('name', 0)
                                print (f'{greenb}Thêm thành công')
                                #
                                json_them_md = self.get_data_account_mat_dinh()
                                json_them_md['account']['loai_tai_khoan'] = 'facebook'
                                json_them_md['account']['thong_tin'] = {'name':name_a,'uid':uid_a,'username':username_a,'password':'','2fa':'','cookie':data_them['cookie_fb'],
                                                                        'token':'','proxy':data_them['proxy_f'],
                                                                        'email':{'email':'','pass_email':''}}
                                json_them_md['more']['name_account_chay'] =  json_acc_chay['username']
                                json_them_md['more']['name_cau_hinh_chay'] = 'delay_mat_dinh'
                                json_them_md['more']['type_chay'] = 'tds'
                                data_cu = data.get ('list_acc',{})
                                data_cu[json_them_md['name_random']] = json_them_md
                                data['list_acc'] = data_cu
                            else:
                                print (f'{redb}Cookie die hoặc không lấy được thông tin cookie.')
                        elif (lua_chon == 'p'):
                            return main ()
                        elif (lua_chon == '2'):
                            break
                        print (f'{mauu_ngau_nhien}{thanhngang}')#
                elif (lua_chon == 'p'):
                    return main ()
                elif (lua_chon == '2'):
                    break
                print (f'{mauu_ngau_nhien}{thanhngang}')#