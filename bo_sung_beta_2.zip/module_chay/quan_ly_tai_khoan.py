import requests
class quan_ly_tai_khoan:
    def them_tai_khoan(self, json_them):
        try:
            global data
            list_account = data.get ('list_acc', {})
            list_account[json_them['name_random']] = json_them
            data['list_acc'] = list_account
            return True
        except Exception as e:
            print (e)
            return False
    def xoa_tai_khoan (self, id_name):
        try:
            global data
            list_account = data.get ('list_acc', {})
            del list_account[id_name]
            data['list_acc'] = list_account
            return True
        except Exception as e:
            print (e)
            return False
    def chinh_sua_data (self, json_moi):
        try:
            global data
            list_account = data.get ('list_acc', {})
            list_account[json_moi['name_random']]  = json_moi
            data['list_acc'] = list_account
            return True
        except Exception as e:
            print (e)
            return False
    def edit_cau_hinh (self,json_moi):
        try:
            global data
            cau_hinh_chay = data.get ('cau_hinh_chay', {})
            cau_hinh_chay['cau_hinh_chay'][json_moi['name_random']]  = json_moi
            data['list_acc'] = cau_hinh_chay
            return True
        except Exception as e:
            print (e)
            return False
    def get_cau_hinh_mat_dinh (self):
        return {
            'jobs':{
                'cam_xuc':True,
                'follow':True,
                'comment':False,
                'share':False,
                'like_page':False
            },
            'delay':{
                'doi_acc_khi_lam_duoc_so_jobs':10,
                'delay_lam_nhiem_vu':{
                    'thanh_cong':{
                        'cam_xuc':{
                            'min':10, 'max':10
                            },
                        'follow':{
                            'min':10, 'max':10
                            },
                        'comment':{
                            'min':10, 'max':10
                            },
                        'share':{
                            'min':10, 'max':10
                            },
                        'like_page':{
                            'min':10, 'max':10
                            },
                        },
                    'that_bai':{
                        'cam_xuc':{
                            'min':10, 'max':10
                            },
                        'follow':{
                            'min':10, 'max':10
                            },
                        'comment':{
                            'min':10, 'max':10
                            },
                        'share':{
                            'min':10, 'max':10
                            },
                        'like_page':{
                            'min':10, 'max':10
                            },
                        }
                    },
                'chong_block':
                    {
                        'lam_so_jobs_thi_delay':{
                            'cam_xuc':{
                                'min':10, 'max':10
                                },
                            'follow':{
                                'min':10, 'max':10
                                },
                            'comment':{
                                'min':10, 'max':10
                                },
                            'share':{
                                'min':10, 'max':10
                                },
                            'like_page':{
                                'min':10, 'max':10
                                },
                        },
                        'so_giay_dung':30
                    },
                'doi_acc':{
                    'dat_tong_so_jobs_thanh_cong':
                    {
                        'cam_xuc':10,
                        'follow':10,
                        'comment':10,
                        'share':10,
                        'like_page':10
                    },
                    'dat_tong_so_jobs_loi':
                    {
                        'cam_xuc':2,
                        'follow':2,
                        'comment':2,
                        'share':2,
                        'like_page':2
                    },
                    'chay_duoc_so_giay':180,
                    'so_xu_kiem_dat':30000,
                },
                'dung_chay':{
                    'dat_tong_so_jobs_thanh_cong':
                    {
                        'cam_xuc':100,
                        'follow':100,
                        'comment':100,
                        'share':100,
                        'like_page':100
                    },
                    'dat_tong_so_jobs_loi':
                    {
                        'cam_xuc':10,
                        'follow':10,
                        'comment':10,
                        'share':10,
                        'like_page':10
                    },
                    'chay_duoc_so_giay':3600,
                    'so_xu_kiem_dat':300000,
                    'tong_xu_dat':99999999
                }
            }
        }
    def get_data_account_mat_dinh (self):
        return {
            'name_random':generate_random_string (15),
            'account':{
                'loai_tai_khoan':'',
                'thong_tin':{
                    'name':'',
                    'uid':'',
                    'username':'',
                    'password':'',
                    '2fa':'',
                    'cookie':'',
                    'token':'',
                    'proxy':'',
                    'email':{
                        'email':'',
                        'pass_email':''
                    }
                },
                'trang_thai':{
                    'proxy_status':'none',
                    'cookie_status': 'live',
                    'action_status':'none' #blocked , not blocked
                }
            },
            'more':{
                'type_chay':'tds',
                'name_account_chay':'',
                'name_cau_hinh_chay': 'delay_mat_dinh',
            },
            'session': requests.Session()
        }
    def get_data_account_chay_mat_dinh (self):
        return {
            'name_random':generate_random_string (15),
            'username':'',
            'authorization':'',
            'token':'',
            'proxy':'',
            'coin': 0
        }