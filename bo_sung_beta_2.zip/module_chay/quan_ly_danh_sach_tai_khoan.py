#khai bao mau co ban
redb, red, green, black, blackb, white, whiteb, yellow, yellowb, syan, blue, blueb, purple, purpleb, lightblue, lightblueb, thanhngang, icon1, icon2, dau,greenb = "\033[1;31m", "\033[1;31m", "\033[1;32m", "\033[0;30m", "\033[1;30m", "\033[1;37m", "\033[1;37m", "\033[0;33m", "\033[1;33m", "\033[1;36m", "\033[0;34m", "\033[1;34m", "\033[0;35m", "\033[1;35m", "\033[0;36m", "\033[1;36m", "══════════════════════════════════════════════════════════════", "•[✩]➭", "\033[1;33m•[۞] ➭  \033[1;37m", "\033[1;31m[\033[1;37m×.×\033[1;31m] \033[1;37m➩","\033[1;32m"
#import thư viện

import os,sys,zipfile,random,requests,string,json,time,subprocess,threading,io,pickle
from tqdm import tqdm 
#tắt log requests
import logging,urllib3
logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)
urllib3.disable_warnings()
from colorama import Fore, Back, Style
from colorama import init, AnsiToWin32
from requests import post
from rich.table import Table
from rich.console import Console
from rich.live import Live
from rich.progress import Progress
from rich import box

class main_chay_quan_ly_ds_chay:
    def get_table_ds_tai_khoan (self):
        global data
        table = Table(title="[bold bright_yellow]Danh sách Delay", box=box.DOUBLE, style="bright_white",show_lines=True)
        list_hien_thi = {
            'ID_T':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'STT':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'TYPE':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'UID/USERNAME':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'NAME':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'PASSWORD':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            '2FA':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'COOKIE':[True,{'justify':'center','style':'bold white','width':15,'no_wrap':True}],
            'PROXY':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'EMAIL/PASSMAIL':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Proxy_Status':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Cookie_Status':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Action_Status':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'U_A':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'NAME_CONFIG':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            }
        for name,value in list_hien_thi.items():
            if (value[0] == True):
                table.add_column(f"[bold white]{name}", justify=value[1]['justify'], style=value[1]['style'],width=value[1]['width'],no_wrap=value[1]['no_wrap'],overflow="ellipsis")
        dem = 0
        if (data.get('list_acc', {}) == {}):
            return table
        for id_dau, value in data.get('list_acc', {}).items():
            name_r = value['name_random']
            type_ac= value['account']['loai_tai_khoan']
            uid_a= value['account']['thong_tin']['uid']
            username_a= value['account']['thong_tin']['username']
            name_a= value['account']['thong_tin']['name']
            passw_a= value['account']['thong_tin']['password']
            fa_a=value['account']['thong_tin']['2fa']
            cookie_a=value['account']['thong_tin']['cookie']
            proxy_a= value['account']['thong_tin']['proxy']
            email_a= value['account']['thong_tin']['email']['email']
            passemail_a=value['account']['thong_tin']['email']['pass_email']
            user_acc_C = value['more']['name_account_chay']
            loai_acc_c = value['more']['type_chay']
            name_Setting = value['more']['name_cau_hinh_chay']
            proxy_sts = value['account']['trang_thai']['proxy_status']
            cookie_sts=  value['account']['trang_thai']['cookie_status']
            action_sts = value['account']['trang_thai']['action_status']
            list_json_dt = {
                    'ID_T':name_r,
                    'STT':str(dem),
                    'TYPE':type_ac,
                    'UID/USERNAME':f'{uid_a}/{username_a}',
                    'NAME':name_a,
                    'PASSWORD':passw_a,
                    '2FA':fa_a,
                    'COOKIE':cookie_a,
                    'PROXY':proxy_a,
                    'EMAIL/PASSMAIL':f'{email_a}/{passemail_a}',
                    'Proxy_Status':proxy_sts,
                    'Cookie_Status':cookie_sts,
                    'Action_Status':action_sts,
                    'U_A':f'[bold yellow]{loai_acc_c}:[cyan]{user_acc_C}',
                    'NAME_CONFIG':name_Setting
                    }
            list_row_them=[]
            for name_value,value in list_hien_thi.items(): 
               if (value[0] == True):
                    list_row_them.append (list_json_dt[name_value])
            table.add_row(*map(str, list_row_them))
            dem+=1
        return table

    def hien_thi_danh_sach_tai_khoan(self):
        global data
        clean_bar()
        list_name= []
        toa_do_mat_dinh = {"x":0,"y":0}
        with Live(console=console,  auto_refresh=True) as live:
            list_id_chon = []
            list_stt_chon = []
            panel = Panel("""[bold red][[bold yellow]i[/bold yellow]][/bold red] [bold white] Để chọn tất cả tài khoản đã chọn\n\
    [bold red][[bold yellow]b[/bold yellow]][/bold red] [bold white] Để xoá tất cả những tài khoản đã chọn\n\
    [bold red][[bold yellow]n[/bold yellow]][/bold red] [bold white] Để chỉnh cấu hình delay,cookie, tài khoản golike,proxy,...\n\
    [bold red][[bold yellow]u[/bold yellow]][/bold red] [bold white] Để cập nhập thông tin tài khoản, trạng thái cookie, trạng thái proxy,...\
    """, title="SHORT KEYS", border_style="cyan")
            panel_2 = Panel("""[bold red][[bold yellow]1[/bold yellow]][/bold red] [bold white] Để chạy jobs kiếm xu\
    """, title="SHORT KEYS 2", border_style="red")
            while True:
                table = self.get_table_ds_tai_khoan ()
                group = Group(table,panel,panel_2)
                live.update (group)
                if (len(table.rows) == 0):
                    input (f'{redb}Vui lòng thêm ít nhất 1 tài khoản')
      
                    return self.main_ui()
                table.title= f'BẤM ENTER ĐỂ CHỌN, ĐÃ CHỌN {len (list_stt_chon)} tài khoản'
                for stt_ in range (len (table.rows)):
                    table.rows[toa_do_mat_dinh["x"]].style = "on default"
                chon_input= getch ()
                if (giao_dien_terminal().check_key (chon_input, 'down')):
                    toa_do_mat_dinh["x"] += 1
                elif (giao_dien_terminal().check_key (chon_input, 'up')):
                    toa_do_mat_dinh["x"] -= 1
                elif (giao_dien_terminal().check_key (chon_input, 'enter')):
                    if (toa_do_mat_dinh["x"]  in list_stt_chon):
                        list_stt_chon.remove (toa_do_mat_dinh["x"] )
                    else:
                        list_stt_chon.append (toa_do_mat_dinh["x"] )
                elif (giao_dien_terminal().check_key (chon_input, 'i')):
                    for stt___ in range (len (table.rows)):
                        if stt___ in list_stt_chon:
                            list_stt_chon.remove (stt___)
                        else:
                            list_stt_chon.append (stt___)
                elif (giao_dien_terminal().check_key (chon_input, 'p')):
           
                    return main ()
                elif (giao_dien_terminal().check_key (chon_input, 'b')):
                    for uid in list_id_chon:
                        self.xoa_tai_khoan (uid)
                        list_id_chon = []
                        list_stt_chon = []
                        toa_do_mat_dinh = {"x":0,"y":0}
                        continue
                elif (giao_dien_terminal().check_key (chon_input, 'n')):
      
                    for i, (id_dau, value) in enumerate(data.get('list_acc', {}).items()):
                        if (i == toa_do_mat_dinh["x"]):
                            return self.sua_thong_tin_tai_khoan (list_id_chon,id_dau)
                            break
                elif (giao_dien_terminal().check_key (chon_input, 'u')):
                    
                    return check_data_acc_chay_().check_update_data_da_luong  (list_id_chon)
                elif (giao_dien_terminal().check_key (chon_input, '1')):
         
                    return self.chay_list  (list_id_chon)
                if (toa_do_mat_dinh["x"] < 0 ):
                    toa_do_mat_dinh["x"]= len(table.rows)-1
                elif toa_do_mat_dinh["x"] >=len(table.rows):
                    toa_do_mat_dinh["x"]=0

                table.rows[toa_do_mat_dinh["x"]].style = "on green"
                for stt_da_chon in list_stt_chon:
                    if (stt_da_chon == toa_do_mat_dinh["x"]):
                        table.rows[stt_da_chon].style = "on green"
                    else:
                        table.rows[stt_da_chon].style = "on yellow"
                time.sleep (0.05)

                list_id_chon = []
                for stt_ in list_stt_chon:
                    for i, (id_dau, value) in enumerate(data.get('list_acc', {}).items()):
                        if (i == stt_):
                            list_id_chon.append (id_dau)
                            break
   
    def sua_thong_tin_tai_khoan (self,list_sua,name_tk_sua):
        global data
        panel = Panel("""[bold red][[bold yellow]0[/bold yellow]][/bold red] [bold white] Cookie\n\
[bold red][[bold yellow]1[/bold yellow]][/bold red] [bold white] Proxy\n\
[bold red][[bold yellow]2[/bold yellow]][/bold red] [bold white] Config Setting\n\
[bold red][[bold yellow]3[/bold yellow]][/bold red] [bold white] Account Golike\\ Account TDS\
""", title="SHORT KEYS", border_style="cyan")
        console.print (panel)
        if (len (list_sua) == 0):
            list_sua.append (name_tk_sua)
        while True:
            chon_input= getch ()
            if (giao_dien_terminal().check_key (chon_input, 'p')):return main ()
            elif (giao_dien_terminal().check_key (chon_input, '0')):
                cookie_moi = input (f'{yellowb}Nhập Cookie mới: {whiteb}')
                data['list_acc'][name_tk_sua]['account']['thong_tin']['cookie'] = cookie_moi
                return True
            elif (giao_dien_terminal().check_key (chon_input, '1')):
                proxy_moi = input (f'{yellowb}Nhập Proxy mới: {whiteb}')
                data['list_acc'][name_tk_sua]['account']['thong_tin']['proxy'] = proxy_moi
                return True
            elif (giao_dien_terminal().check_key (chon_input, '2')):
                panel = Panel("""[bold white] Dùng phím mũi tênn hoặc wasd để di chuyển tuỳ chọn\n\
[bold white] Enter để chọn\n\
        """, title="SHORT KEYS", border_style="cyan")
                console.print (panel)
                list_chon =[]
                for name_st, value in data['ds_cau_hinh'].items():
                    list_chon.append ({'text':f'[bold red][[bold yellow]{name_st}[/bold yellow]][/bold red] [bold white] Config đã tạo...',
            "chon":name_st})
                print (f'{whiteb}Danh sách Config đã tạo')
                lua_chon = load_list_chon (list_chon,clear=False,in_help=False)
                if lua_chon == 'p':return main ()
                for name_R in list_sua:
                    data['list_acc'][name_R]['more']['name_cau_hinh_chay'] = lua_chon
                return True
            elif (giao_dien_terminal().check_key (chon_input, '3')):
                panel = Panel("""[bold white] Dùng phím mũi tênn hoặc wasd để di chuyển tuỳ chọn\n\
[bold white] Enter để chọn\n\
        """, title="SHORT KEYS", border_style="cyan")
                console.print (panel)
                list_chon =[]
                list_name_R = {}
                list_name_R['golike'] = []
                list_name_R['tds'] = []
                for name_R in list_sua:
                    loai_acc_c = data['list_acc'][name_R]['more']['type_chay']
                    list_name_R[loai_acc_c].append(name_R)
                
                if ( len (list_name_R['golike']) != 0):
                    for name_st, value in data['golike'].items():
                        list_chon.append ({'text':f'[bold red][[bold yellow]{name_st}[/bold yellow]][/bold red] [bold white] Acc Golike',
                "chon":name_st})
                    print (f'{whiteb}Danh sách Acc Golike')
                    lua_chon = load_list_chon (list_chon,clear=False,in_help=False)
                    if lua_chon == 'p':return main ()
                    for name_R in list_name_R['golike'] :
                        data['list_acc'][name_R]['more']['name_account_chay'] = lua_chon
                if (len (list_name_R['tds']) != 0):
                    for name_st, value in data['tds'].items():
                        list_chon.append ({'text':f'[bold red][[bold yellow]{name_st}[/bold yellow]][/bold red] [bold white] Acc TDS',
                "chon":name_st})
                    print (f'{whiteb}Danh sách Acc TraoDoiSub')
                    lua_chon = load_list_chon (list_chon,clear=False,in_help=False)
                    if lua_chon == 'p':return main ()
                    for name_R in list_name_R['tds']:
                        data['list_acc'][name_R]['more']['name_account_chay'] = lua_chon
                return True