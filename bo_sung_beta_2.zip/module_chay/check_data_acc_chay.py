import threading
class check_data_acc_chay_:
    def check_Data_acc_Chay (self,name_random):
        global data
        value=data['list_acc'][name_random]

        name_r = value['name_random']
        type_ac= value['account']['loai_tai_khoan']
        uid_a= value['account']['thong_tin']['uid']
        username_a= value['account']['thong_tin']['username']
        name_a= value['account']['thong_tin']['name']
        passw_a= value['account']['thong_tin']['password']
        fa_a=value['account']['thong_tin']['2fa']
        cookie_a=value['account']['thong_tin']['cookie']
        proxy_a= value['account']['thong_tin']['proxy']
        email_a= value['account']['thong_tin']['email']['email']
        passemail_a=value['account']['thong_tin']['email']['pass_email']
        user_acc_C = value['more']['name_account_chay']
        name_Setting = value['more']['name_cau_hinh_chay']
        proxy_sts = value['account']['trang_thai']['proxy_status']
        cookie_sts=  value['account']['trang_thai']['cookie_status']
        action_sts = value['account']['trang_thai']['action_status']
        
        session =  value['session']
        #check proxy ##invalid , live, die
        with self.lock:
            check_proxxy_ = check_proxy (proxy_a)
            value['account']['trang_thai']['proxy_status']= check_proxxy_['trangthai']
            value['session'] = check_proxxy_['session']
        #check cookie
        if (type_ac  == 'facebook'):
            fb_tools = facebook_tools_requests(cookie =cookie_a , req= value['session'] )
            thong_tin= fb_tools.get_thongtin()
            if (thong_tin.get ('trangthai', False)):
                with self.lock:
                    value['account']['thong_tin']['name'] =  thong_tin.get ('name', 0)
                    value['account']['thong_tin']['uid'] = thong_tin.get ('id', 0)
                    value['account']['thong_tin']['username'] = thong_tin.get ('username', 'null')
            else:
                with self.lock:
                    value['account']['trang_thai']['cookie_status'] = 'die'
        with self.lock:
            data['list_acc'][name_random] =value
        return True
    def check_update_data_da_luong (self,list_id_chon):
        if (len(list_id_chon) == 0):
            print (f'{redb}Vui lòng chọn ít nhất 1 tài khoản')
        progress = Progress()
        progress.start()
        task_id = progress.add_task(f"Đang Check", total=len (list_id_chon))
        self.lock = threading.Lock()
        threads = []
        for uid in list_id_chon:
            t = threading.Thread(target=self.check_Data_acc_Chay,args= (uid,))
            threads.append(t)
            t.start()
        while True:
            if (len (threads) == 0):
                break
            for thread in threads:
                time.sleep (0.5)
                if not(thread.is_alive()):
                    threads.remove (thread)
                    progress.update(task_id, advance=1) 
        progress.stop ()
        print (f'{greenb}Update thành công')
        