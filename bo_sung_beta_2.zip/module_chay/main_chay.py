#khai bao mau co ban
redb, red, green, black, blackb, white, whiteb, yellow, yellowb, syan, blue, blueb, purple, purpleb, lightblue, lightblueb, thanhngang, icon1, icon2, dau,greenb = "\033[1;31m", "\033[1;31m", "\033[1;32m", "\033[0;30m", "\033[1;30m", "\033[1;37m", "\033[1;37m", "\033[0;33m", "\033[1;33m", "\033[1;36m", "\033[0;34m", "\033[1;34m", "\033[0;35m", "\033[1;35m", "\033[0;36m", "\033[1;36m", "══════════════════════════════════════════════════════════════", "•[✩]➭", "\033[1;33m•[۞] ➭  \033[1;37m", "\033[1;31m[\033[1;37m×.×\033[1;31m] \033[1;37m➩","\033[1;32m"
#import thư viện

import os,sys,zipfile,random,requests,string,json,time,subprocess,threading,io,pickle
from tqdm import tqdm 
#tắt log requests
import logging,urllib3
logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)
urllib3.disable_warnings()
from colorama import Fore, Back, Style
from colorama import init, AnsiToWin32
from requests import post
from rich.table import Table
from rich.console import Console
from rich.live import Live
from rich.progress import Progress
from rich import box

class main_chay (quan_ly_tai_khoan,main_chay_quan_ly_ds_chay,Quan_ly_cau_Hinh_gui,trang_them_tai_khoan_ui,chay_kiem_jobs_ui):
    def main_ui(self):
        global data
        if (data.get ('ds_cau_hinh', {}).get ('delay_mat_dinh', {})  == {}):
            print ('đã tạo file cấu hìnnh mặt định')
            data['ds_cau_hinh'] = {}
            data['ds_cau_hinh']['delay_mat_dinh'] = self.get_cau_hinh_mat_dinh()
        clean_bar()
        list_chon = [
    {'text':f'[bold red][[bold yellow]ADD[/bold yellow]][/bold red] [bold white] Thêm Tài Khoản',
    "chon":'add'},
    {'text':f'[bold red][[bold yellow]CONFIG[/bold yellow]][/bold red] [bold white] Quản Lý Config Delay, Jobs cấu hình,..',
    "chon":'config'},
    {'text':f'[bold red][[bold yellow]DS[/bold yellow]][/bold red] [bold white] Danh sách tài khoản & chạy',
    "chon":'ds'},
      ] 
        lua_chon = load_list_chon (list_chon)
        if (lua_chon == 'p'):
            return main ()
        elif (lua_chon == 'add'):
            self.them_tai_khoan_ui ()
        elif (lua_chon == 'ds'):
            self.hien_thi_danh_sach_tai_khoan ()
        elif (lua_chon == 'config'):
            self.trang_add_config()
        else:
            print (f'{redb}Lựa chọn không hợp lệ')
        input (f'{lightblueb}Enter để tiếp tục')
    
    