
class chay_kiem_jobs_ui:
    def tao_thong_tin_table (self,name_random):
        global table_chay_1,data
        value=data['list_acc'][name_random]
        name_r = value['name_random']
        type_ac= value['account']['loai_tai_khoan']
        uid_a= value['account']['thong_tin']['uid']
        username_a= value['account']['thong_tin']['username']
        name_a= value['account']['thong_tin']['name']
        cookie_a=value['account']['thong_tin']['cookie']
        proxy_a= value['account']['thong_tin']['proxy']
        user_acc_C = value['more']['name_account_chay']
        loai_acc_c = value['more']['type_chay']
        check_proxxy_ = check_proxy (proxy_a)
        requests_session=check_proxxy_['session']
        if (loai_acc_c == 'tds'):
            data_Tds = data['tds'][user_acc_C]
            check_proxxy_Golike = check_proxy (data_Tds['proxy'])
            chay_tools= TDS_MODULE_V2 (token =data_Tds['token'], req=check_proxxy_Golike['session'])
            if (type_ac == 'facebook'):
                chay_tools = chay_tools.TDS_MODULE_FACEBOOK (token =data_Tds['token'], req=check_proxxy_Golike['session'])
        if (type_ac=='facebook'):
            tools_tt  = facebook_tools_requests(cookie =cookie_a , req= requests_session )
        table_chay_1[name_random] ={
            'id_r':name_random,
            'type_ac':type_ac,
            'uid_a':uid_a,
            'username_a':username_a,
            'name_a':name_a,
            'user_acc_C':user_acc_C,
            'type_chay':loai_acc_c,
            'mess':'[bold white]Đang Đợi Luồng',
            'tools_tt':tools_tt,
            'chay_tools': chay_tools,
            'jobs':{
                'jobs done': {
                   'cam_xuc':0,
                    'follow':0,
                    'comment':0,
                    'share':0,
                    'like_page':0,
                },
                'jobs error': {
                    'cam_xuc':0,
                    'follow':0,
                    'comment':0,
                    'share':0,
                    'like_page':0,
                },
            },
            'coin':{
                'cam_xuc':0,
                'follow':0,
                'comment':0,
                'share':0,
                'like_page':0,
            }
        }
    def dung_luong (self,name_random):
        global data
        return ''
    def dung_luong_va_dung_chay (self,name_random):
        global data
        time.sleep (2)
        self.list_acc.remove(name_random)
        return ''
    def chay_kiem_jobs (self,name_random):
        global data,table_chay_1
        value=data['list_acc'][name_random]
        loai_acc_c = value['more']['type_chay']
        if (loai_acc_c == 'tds'):self.chay_kiem_jobs_tds (name_random)
    def set_text_luong (self,name_random, text):
        global data,table_chay_1
        with self.lock_threading:table_chay_1[name_random]['mess'] = f'{text}'
    def chay_kiem_jobs_golike (self,name_random):pass
    def chay_kiem_jobs_tds (self,name_random):
        def chuyen_jobs  (name):
            if (name in ['facebook_reaction', 'facebook_reactioncmt'] ):
                return 'cam_xuc'
            elif name == 'facebook_share':
                return 'share'
            elif name == 'facebook_follow':
                return 'follow'
            elif name == 'facebook_page':
                return 'like_page'
        from datetime import datetime, timedelta
        global data,table_chay_1
        self.set_text_luong (name_random,f'[bold yellow]Đang đọc giá trị' )
        value=data['list_acc'][name_random]
        name_r = value['name_random']
        type_ac= value['account']['loai_tai_khoan']
        uid_a= value['account']['thong_tin']['uid']
        username_a= value['account']['thong_tin']['username']
        name_a= value['account']['thong_tin']['name']
        passw_a= value['account']['thong_tin']['password']
        fa_a=value['account']['thong_tin']['2fa']
        cookie_a=value['account']['thong_tin']['cookie']
        proxy_a= value['account']['thong_tin']['proxy']
        email_a= value['account']['thong_tin']['email']['email']
        passemail_a=value['account']['thong_tin']['email']['pass_email']
        user_acc_C = value['more']['name_account_chay']
        name_Setting = value['more']['name_cau_hinh_chay']
        proxy_sts = value['account']['trang_thai']['proxy_status']
        cookie_sts=  value['account']['trang_thai']['cookie_status']
        action_sts = value['account']['trang_thai']['action_status']
        session =  value['session']
        # CONFIG
        config_value = data['ds_cau_hinh'][name_Setting]
        config_delay =  data['ds_cau_hinh'][name_Setting]['delay']['delay_lam_nhiem_vu']
        config_block =  data['ds_cau_hinh'][name_Setting]['delay']['chong_block']
        config_doi_acc = data['ds_cau_hinh'][name_Setting]['delay']['doi_acc']
        config_dung_chay = data['ds_cau_hinh'][name_Setting]['delay']['dung_chay']
        self.dtl.setdefault (name_random, {})
        self.dtl[name_random]['thoi_gian_bat_dau']= datetime.now()
        self.dtl[name_random]['thoi_gian_doi_acc'] =datetime.now() + timedelta(seconds=config_doi_acc['chay_duoc_so_giay'])
        if self.dtl.get(name_random, {}).get ('thoi_gian_ket_thuc',True):
            self.dtl[name_random]['thoi_gian_ket_thuc']= datetime.now() + timedelta(seconds=config_dung_chay['chay_duoc_so_giay'])
        self.dtl[name_random]['data_phien'] ={'jobs':{
                'jobs done': {
                   'cam_xuc':0,
                    'follow':0,
                    'comment':0,
                    'share':0,
                    'like_page':0,
                },
                'jobs error': {
                    'cam_xuc':0,
                    'follow':0,
                    'comment':0,
                    'share':0,
                    'like_page':0,
                },
            },
            'coin':{
                'cam_xuc':0,
                'follow':0,
                'comment':0,
                'share':0,
                'like_page':0,
            }}
        # lây list_nv:
        jobs= config_value['jobs']
        list_nv_lam = []
        if (jobs['cam_xuc']):
            list_nv_lam.append ('facebook_reaction')
            list_nv_lam.append ('facebook_reactioncmt')
        if (jobs['share']):list_nv_lam.append ('facebook_share')
        if (jobs['follow']):list_nv_lam.append ('facebook_follow')
        if (jobs['like_page']):list_nv_lam.append ('facebook_page')

        # Lấy giá trị
        tuong_tac_tools = table_chay_1[name_random]['tools_tt']
        tds_tools = table_chay_1[name_random]['chay_tools']
        if (tds_tools.countdown != 0):
            for dem_delay in range (tds_tools.countdown + 5,0,-1):
                self.set_text_luong (name_random,f'[bold #93ff00]Đang Delay countdown, còn [bold #ffa100]{dem_delay} [bold #93ff00]giây')
                time.sleep (1.02)
        self.set_text_luong (name_random,f'[bold #00fdff]Đang check cấu hình')
        ch = tds_tools.cau_hinh (uid_a)
        if (ch['trangthai'] != True):
            if tds_tools.countdown != 0:
                self.set_text_luong (name_random,f'[bold #ff5a00]Cấu hình UID [bold #cfff00]{uid_a} [bold #ff5a00]thất bại' )
                time.sleep(3)
                return self.dung_luong (name_random)
            else:
                self.set_text_luong (name_random,f'[bold #ff5a00]UID [bold #cfff00]{uid_a} [bold #ff5a00]chưa được cấu hình' )
                time.sleep(3)
                return self.dung_luong_va_dung_chay (name_random)
        while True:
            
            # check để dừng tools 
            time_ht = datetime.now() 
            if (self.dtl[name_random]['thoi_gian_ket_thuc'] < time_ht):
                self.set_text_luong (name_random,f'[bold cyan]Đạt thời gian đã set. Dừng chạy' )
                return self.dung_luong_va_dung_chay (name_random)
  
            # thanh cong va tb
            jobs_done = table_chay_1[name_random]['jobs']['jobs done']
            jobs_error = table_chay_1[name_random]['jobs']['jobs error']
            coin_done = table_chay_1[name_random]['coin']
            cong_fig_dung_acc_tc = config_dung_chay['dat_tong_so_jobs_thanh_cong']
            cong_fig_dunng_tb = config_dung_chay['dat_tong_so_jobs_loi']
            if (jobs_done['cam_xuc'] >=cong_fig_dung_acc_tc['cam_xuc'] or 
                jobs_error['cam_xuc'] >=cong_fig_dunng_tb['cam_xuc']):
                self.set_text_luong (name_random,f'[bold cyan]Đạt số jobs Cảm xúc đã set. Dừng chạy' )
                return self.dung_luong_va_dung_chay (name_random)
            if (jobs_done['follow'] >=cong_fig_dung_acc_tc['follow'] or 
                jobs_error['follow'] >=cong_fig_dunng_tb['follow']):
                self.set_text_luong (name_random,f'[bold cyan]Đạt số jobs follow đã set. Dừng chạy' )
                return self.dung_luong_va_dung_chay (name_random)
            if (jobs_done['comment'] >=cong_fig_dung_acc_tc['comment'] or 
                jobs_error['comment'] >=cong_fig_dunng_tb['comment']):
                self.set_text_luong (name_random,f'[bold cyan]Đạt số jobs comment đã set. Dừng chạy' )
                return self.dung_luong_va_dung_chay (name_random)
            if (jobs_done['share'] >=cong_fig_dung_acc_tc['share'] or 
                jobs_error['share'] >=cong_fig_dunng_tb['share']):
                self.set_text_luong (name_random,f'[bold cyan]Đạt số jobs share đã set. Dừng chạy' )
                return self.dung_luong_va_dung_chay (name_random)
            if (jobs_done['like_page'] >=cong_fig_dung_acc_tc['like_page'] or 
                jobs_error['like_page'] >=cong_fig_dunng_tb['like_page']):
                self.set_text_luong (name_random,f'[bold cyan]Đạt số jobs like_page đã set. Dừng chạy' )
                return self.dung_luong_va_dung_chay (name_random)
            
            # doi tai khoan
            table_chay_1[name_random]
            if (self.dtl[name_random]['thoi_gian_doi_acc'] < time_ht):
                self.set_text_luong (name_random,f'[bold cyan]Đạt thời gian đã set. Đổi acc' )
                return self.dung_luong (name_random)
            # thanh cong va tb
            jobs_done = self.dtl[name_random]['data_phien']['jobs']['jobs done']
            jobs_error = self.dtl[name_random]['data_phien']['jobs']['jobs error']
            coin_done = self.dtl[name_random]['data_phien']['coin']
            cong_fig_doi_acc_tc = config_doi_acc['dat_tong_so_jobs_thanh_cong']
            cong_fig_doi_acc_tb = config_doi_acc['dat_tong_so_jobs_loi']
            if (jobs_done['cam_xuc'] >=cong_fig_doi_acc_tc['cam_xuc'] or 
                jobs_error['cam_xuc'] >=cong_fig_doi_acc_tb['cam_xuc']):
                self.set_text_luong (name_random,f'[bold cyan]Đạt số jobs Cảm xúc đã set. Đổi acc chạy' )
                return self.dung_luong_va_dung_chay (name_random)
            if (jobs_done['follow'] >=cong_fig_doi_acc_tc['follow'] or 
                jobs_error['follow'] >=cong_fig_doi_acc_tb['follow']):
                self.set_text_luong (name_random,f'[bold cyan]Đạt số jobs follow đã set. Đổi acc chạy' )
                return self.dung_luong_va_dung_chay (name_random)
            if (jobs_done['comment'] >=cong_fig_doi_acc_tc['comment'] or 
                jobs_error['comment'] >=cong_fig_doi_acc_tb['comment']):
                self.set_text_luong (name_random,f'[bold cyan]Đạt số jobs comment đã set. Đổi acc chạy' )
                return self.dung_luong_va_dung_chay (name_random)
            if (jobs_done['share'] >=cong_fig_doi_acc_tc['share'] or 
                jobs_error['share'] >=cong_fig_doi_acc_tb['share']):
                self.set_text_luong (name_random,f'[bold cyan]Đạt số jobs share đã set. Đổi acc chạy' )
                return self.dung_luong_va_dung_chay (name_random)
            if (jobs_done['like_page'] >=cong_fig_doi_acc_tc['like_page'] or 
                jobs_error['like_page'] >=cong_fig_doi_acc_tb['like_page']):
                self.set_text_luong (name_random,f'[bold cyan]Đạt số jobs like_page đã set. Đổi acc chạy' )
                return self.dung_luong_va_dung_chay (name_random)
            
            self.set_text_luong (name_random,f'[bold #00fdff]Đang Get Jobs')
            get_jobs = tds_tools.get_list_jobs (list_nv = list_nv_lam)
            if (tds_tools.countdown != 0):
                for dem_delay in range (tds_tools.countdown + 5,0,-1):
                    self.set_text_luong (name_random,f'[bold #93ff00]Đang Delay countdown, còn [bold #ffa100]{dem_delay} [bold #93ff00]giây')
                    time.sleep (1.02)
                continue
            if get_jobs == False:
                self.set_text_luong (name_random,f'[bold #ff0000]Hết Jobs rồii ní ơi')
                time.sleep (1)
                continue
            type_url = get_jobs['type_url']
            type_jobs=get_jobs['type']
            id_post=str (get_jobs['id'])
            if not(type_url in list_nv_lam):
                self.set_text_luong (name_random,f'[bold red]Bạn không cho phép làm jobs [bold yellow]{type_url}[bold red], đã bỏ qua')
                time.sleep (2)
                continue
            self.set_text_luong (name_random,f'[bold white]Thực hiện [bold yellow]{type_jobs}')
            if (chuyen_jobs (type_url)=='cam_xuc'):
                if type_url  == 'facebook_reaction':
                    lam_nv = tuong_tac_tools.CamXuc (id_post =id_post,reaction = type_jobs.lower ())
                elif type_url  == 'facebook_reactioncmt':
                    lam_nv = tuong_tac_tools.CamXuc_cmt (id_post =id_post,reaction = type_jobs.lower ())
            elif (chuyen_jobs (type_url)=='follow'):
                lam_nv = tuong_tac_tools.follow (id_post =id_post)
            elif (chuyen_jobs (type_url)=='like_page'):
                lam_nv = tuong_tac_tools.like_page (id_post =id_post)
                
            else:
                self.set_text_luong (name_random,f'[bold red]Khôg hỗ trợ làm nhiệm vụ [bold yellow]{type_jobs}[bold red], đã bỏ qua')
                continue
            #delay
            print (lam_nv)
            url_cuoi= lam_nv['url']
            if ('/checkpoint/' in url_cuoi):
                if ('/601051028565049/' in url_cuoi ):
                    self.set_text_luong (name_random,f'[bold #ff4b00]Tài khoản bị khoá 049, sẽ unlock sau 3giây')
                    time.sleep(3)
                    self.set_text_luong (name_random,f'[bold #ffc600]Đang tiến hành unlock')
                    tuong_tac_tools.unlock_049()
                    self.set_text_luong (name_random,f'[bold #ffe800]Trạng thái unlock: [bold #ff0000]không rõ')
                    time.sleep(3)
                    continue
            if (lam_nv['trangthai'] == True):tc_tb = 'thanh_cong'
            else:tc_tb = 'that_bai'
            type_nv_dl = chuyen_jobs (type_url)
            dl_min =  config_delay[tc_tb][type_nv_dl]['min']
            dl_max = config_delay[tc_tb][type_nv_dl]['max']
            try:
                time_delay= random.randint(dl_min,dl_max )
            except:
                time_delay= random.randint(dl_max, dl_min)
            for dem_delay in range (time_delay,0,-1):
                self.set_text_luong (name_random,f'[bold #93ff00]Đang Delay nhiệm vụ [bold #00ffba]{type_jobs}[bold #93ff00] còn [bold #ffa100]{dem_delay} [bold #93ff00]giây, Trang thai: [bold #ffa100]{tc_tb}')
                time.sleep (1)

            #
            dt_phien = self.dtl[name_random]['data_phien']
            du_lieu_table=table_chay_1[name_random]
            type_url_t = chuyen_jobs (type_url)
            if lam_nv['trangthai'] == True:
                dt_phien['jobs']['jobs done'][type_url_t] +=1
                du_lieu_table['jobs']['jobs done'][type_url_t] +=1
            else:
                dt_phien['jobs']['jobs error'][type_url_t] +=1
                du_lieu_table['jobs']['jobs error'][type_url_t] +=1
            #hoan_thanh
            if (lam_nv['trangthai'] == True):
                ht = tds_tools.hoan_thanh()
                if (ht['trangthai'] == True):
                    xu_them = ht['xu_them']
                    tong_xu = ht['tong_xu']
                    dt_phien['coin'][type_url_t] +=int (xu_them)
                    du_lieu_table['coin'][type_url_t] +=int (xu_them)
                    self.set_text_luong (name_random,f'[#fffe00]Nhận thành công [#27ff00]{xu_them}[#fffe00] -> [#27ff00]{tong_xu}')
                else:
                    cache = ht['cache']
                    self.set_text_luong (name_random,f'[bold #b8cbff]Cache Jobs Fb: [bold #ffa100]{cache}')
            else:
                self.set_text_luong (name_random,f'[bold red]Làm jobs [bold yellow]{type_jobs}[bold red] thất bại, đã bỏ qua')
            self.dtl[name_random]['data_phien'] = dt_phien
            table_chay_1[name_random] = du_lieu_table
            time.sleep (1)
    def get_table_chay (self):
        global data,table_chay_1
        table = Table(title="[bold bright_yellow]Danh sách Luồng", box=box.DOUBLE, style="bright_white",show_lines=True)
        list_hien_thi = {
            'ID_T':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            '[#9148fe]STT':[True,{'justify':'center','style':'#9148fe','width':None,'no_wrap':True}],
            '[#1bff00]TYPE':[True,{'justify':'center','style':'#1bff00','width':None,'no_wrap':True}],
            '[#ffef00]UID/[#00ffa3]USERNAME':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'NAME':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            '[#d4b5ff]U:[#4576ff]A':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],

            'Total CX Done':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total FL Done':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total CMT Done':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total SHE Done':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total LIKEPAGE Done':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],

            'Total CX Error':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total FL Error':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total CMT Error':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total SHE Error':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total LIKEPAGE Error':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],

            'Coin CX Earn':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Coin FL Earn':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Coin CMT Earn':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Coin SHE Earn':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Coin LIKEPAGE Earn':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            
            'Total CX/FL/CMT/SHE/LIKEPAGE Done':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total CX/FL/CMT/SHE/LIKEPAGE Error':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Coin CX/FL/CMT/SHE/LIKEPAGE Earn':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],

            'Total Jobs Done':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total Jobs Error':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Total Coin Earn':[False,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            '[#ffffff]Total [#1bff00]Jobs Done/[#ff2222]Jobs Error/[#ffd500]Coin Earn':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            'Messenger':[True,{'justify':'center','style':'bold white','width':None,'no_wrap':True}],
            }
        for name,value in list_hien_thi.items():
            if (value[0] == True):
                table.add_column(f"[bold white]{name}", justify=value[1]['justify'], style=value[1]['style'],width=value[1]['width'],no_wrap=value[1]['no_wrap'],overflow="ellipsis")
        dem = 0
        for id_R,value in table_chay_1.items():
            name_r = value['id_r']
            type_ac = value['type_ac']
            uid_a = value['uid_a']
            username_a = value['username_a']
            name_a = value['name_a']
            user_acc_C = value['user_acc_C']
            loai_acc_c = value['type_chay']
            mess = value['mess']

            #
            jobs_done = value['jobs']['jobs done']
            jobs_error= value['jobs']['jobs error']
            coin_earn = value['coin']
            
            ##
            total_jobs_done = jobs_done['cam_xuc'] + jobs_done['follow'] + jobs_done['comment'] +jobs_done['share']+jobs_done['like_page']
            total_jobs_error = jobs_error['cam_xuc'] + jobs_error['follow'] + jobs_error['comment'] +jobs_error['share']+jobs_error['like_page']
            total_coin_eran = coin_earn['cam_xuc'] + coin_earn['follow'] + coin_earn['comment'] +coin_earn['share']+coin_earn['like_page']
            ###
            type_ac = value['type_ac']
            list_json_dt={
            'ID_T':name_r,
            '[#9148fe]STT':str(dem),
            '[#1bff00]TYPE':type_ac,
            '[#ffef00]UID/[#00ffa3]USERNAME':f'[#ffef00]{uid_a}/[#00ffa3]{username_a}',
            'NAME':f'{name_a}',
            'U_Golike':user_acc_C,
            '[#d4b5ff]U:[#4576ff]A':f'[#d4b5ff]{loai_acc_c}:[#4576ff]{user_acc_C}',
            'Total CX Done':str ( jobs_done['cam_xuc']),
            'Total FL Done':str ( jobs_done['follow']),
            'Total CMT Done':str ( jobs_done['comment']),
            'Total SHE Done':str ( jobs_done['share']),
            'Total LIKEPAGE Done':str ( jobs_done['like_page']),

            'Total CX Error':str ( jobs_error['cam_xuc']),
            'Total FL Error':str ( jobs_error['follow']),
            'Total CMT Error':str ( jobs_error['comment']),
            'Total SHE Error':str ( jobs_error['share']),
            'Total LIKEPAGE Error':str ( jobs_error['like_page']),

            'Coin CX Earn':str ( coin_earn['cam_xuc']),
            'Coin FL Earn':str ( coin_earn['follow']),
            'Coin CMT Earn':str ( coin_earn['comment']),
            'Coin SHE Earn':str ( coin_earn['share']),
            'Coin LIKEPAGE Earn':str ( coin_earn['like_page']),
            
            'Total CX/FL/CMT/SHE/LIKEPAGE Done':f"{jobs_done['cam_xuc']}/{jobs_done['follow']}/{jobs_done['comment']}/{jobs_done['share']}/{jobs_done['like_page']}",
            'Total CX/FL/CMT/SHE/LIKEPAGE Error':f"{jobs_error['cam_xuc']}/{jobs_error['follow']}/{jobs_error['comment']}/{jobs_error['share']}/{jobs_error['like_page']}",
            'Coin CX/FL/CMT/SHE/LIKEPAGE Earn':f"{coin_earn['cam_xuc']}/{coin_earn['follow']}/{coin_earn['comment']}/{coin_earn['share']}/{coin_earn['like_page']}",
            'Total Jobs Done':total_jobs_done,
            'Total Jobs Error':total_jobs_error,
            'Total Coin Earn':total_coin_eran,
            '[#ffffff]Total [#1bff00]Jobs Done/[#ff2222]Jobs Error/[#ffd500]Coin Earn': f'[#1bff00]{total_jobs_done}/[#ff2222]{total_jobs_error}/[#ffd500]{total_coin_eran}',
            'Messenger':mess
            }
            list_row_them=[]
            for name_value,value in list_hien_thi.items(): 
               if (value[0] == True):
                    list_row_them.append (list_json_dt[name_value])
            table.add_row(*map(str, list_row_them))
            dem+=1
        return table
    def cap_nhap_trang_thai_luong (self):
        try:
            global data, table_chay_1,data_tool
            dem = 0
            threads =data_tool['luong_chay']['threads'] 
            for name_r, value in data_tool['luong_chay']['threads'].items():
                threads[name_r]['trangthai']=threads[name_r]['luong'].is_alive()
            data_tool['luong_chay']['threads'] = threads
        except:pass
    def lay_tong_luong_dang_chay (self):
        global data, table_chay_1,data_tool
        dem = 0
        for name_r, value in data_tool['luong_chay']['threads'].items():
            if (value['trangthai'] == True):
                dem+=1
        return dem
    def chay_list (self, list_acc, so_luong = 3):
        self.list_acc = list_acc
        global data, table_chay_1,data_tool
        table_chay_1 = {}
        data_tool.setdefault('luong_chay', {}).setdefault('threads', {})

        threads = data_tool.get ('luong_chay',{}).get ('threads',{})
        for id_r in self.list_acc:
            self.tao_thong_tin_table (id_r)
            threads[id_r] = {}
            threads[id_r]['trangthai'] = False

        with Live(console=console,  auto_refresh=True) as live:
    
            self.lock_threading  = threading.Lock()
            self.dtl = {}
            while True:
                time.sleep (0.1)
                if (len ( self.list_acc ) == 0):
                    return ''
                for id_r in self.list_acc:
                    live.update ( self.get_table_chay ())
                    self.cap_nhap_trang_thai_luong ()
                    if threads[id_r]['trangthai'] == False:
                        threads[id_r]['luong']=threading.Thread(target=self.chay_kiem_jobs, args=(id_r,), daemon=True)
                        threads[id_r]['luong'].start()
                        threads[id_r]['trangthai']=threads[id_r]['luong'].is_alive()
                        time.sleep (0.1)
                    data_tool['luong_chay']['threads'] = threads
                    if (self.lay_tong_luong_dang_chay () >=  so_luong):
                        while True:
                            live.update ( self.get_table_chay ())
                            time.sleep (0.5)
                            self.cap_nhap_trang_thai_luong ()
                            if (self.lay_tong_luong_dang_chay () < so_luong):
                                break
                    