
import random,zipfile,threading,string,urllib3,json,hashlib,requests,time,os,base64,sys,socket,platform,logging,re,marshal,subprocess,rich
from rich.progress import Progress
import base64
from colorama import Fore, Back, Style
from colorama import init, AnsiToWin32
from requests import post
from tqdm import tqdm 
import io
import random
def get_thong_tin ():
    global url_host
    try:
        print ('Đang đọc thông tin')
        data = requests.get ('http://kktool.x10.bz/get_version.php',timeout=3).text
        open ('data_kktools_cache', 'w', encoding = 'utf-8').write (data)
    except:
        print ('Kết nối thất bại, đang tìm lại dữ liệu gần nhất')
    try:
        data = json.loads (open ('data_kktools_cache', 'r', encoding = 'utf-8').read ())
        url_host = data['host']
    except:
        print ('Data không hợp lệ, hãy đảm bảo rằng bạn có kết nối internet')
        os._exit(0)
def thuc_hien_lenh (lenh):
    process = subprocess.Popen(lenh,shell=True,
                            stdout=subprocess.PIPE, 
                            stderr=subprocess.PIPE,
                            text=True)
    for stdout_line in iter(process.stdout.readline, ""):
        print(stdout_line, end="")
def randommau():
    rand = random.randint(1, 231)
    if rand <= 7:
        mau = "\033[1;3" + str(random.choice([1, 2, 3, 4, 5, 6, 7])) + "m"
    elif rand >= 8 and rand <= 231:
        rand = random.randint(1, 231)
        while rand == 0:
            rand = random.randint(1, 231)
        mau = "\033[38;5;" + str(rand) + "m"
    print (f'Mã màu: {repr (mau)}')
    return mau
def kiemtrathietbi():return "com.termux" in os.environ.get("PREFIX", "")
def generate_random_string(length):
    characters = string.ascii_letters + string.digits
    random_string = ''.join(random.choice(characters) for _ in range(length))
    return random_string

def downloaddatatool(url, filename):
    try:
        response = requests.get(url, stream=True, timeout=10)
        response.raise_for_status()  # Kiểm tra trạng thái HTTP
        total_size = int(response.headers.get('content-length', 0))  # Kích thước file
        if total_size == 0:
            print(f"Lỗi: Không thể tải file từ {url}")
            return
        with Progress() as progress:
            task1 = progress.add_task("[red]Đang tải...[/]", total=total_size)
            with open(filename, 'wb') as file:
                for data in response.iter_content(chunk_size=1024):
                    size = file.write(data)
                    progress.update(task1, advance=size)
        print(f"Tải xong: {filename}")

    except requests.exceptions.Timeout:
        print("Lỗi: Hết thời gian chờ khi kết nối tới server.")
    except requests.exceptions.RequestException as e:
        print(f"Lỗi: {e}")
def download_and_extract(url, file_path, extract_to):
    print(f'{randommau()}Đang tải module, file con của tool')
    downloaddatatool(url, file_path)
    print(f'{randommau()}Đang tải setup tool')
    with zipfile.ZipFile(file_path, 'r') as fantasy_zip:
        fantasy_zip.extractall(extract_to)
def clean_bar ():
    print("\033[0m")
    if (kiemtrathietbi()):os.system ("clear")
    else:os.system ("cls")
    print("\033[0m")
    console.print (BANNER)
if sys.platform == "win32":
    import msvcrt
else:
    import sys
    import tty
    import termios
    import select
def get_ch_linux ():
    
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        rlist, _, _ = select.select([sys.stdin], [], [], 0)
        tty.setcbreak(fd)
        if rlist:
            ch = sys.stdin.read(1)
            if ch in (b'\x00', b'\xe0', '\x1b'):  # Kiểm tra ký tự bắt đầu của phím mũi tên
                ch += sys.stdin.read(2)  # Đọc thêm 2 ký tự còn lại
            return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
def getch():
    if sys.platform == "win32":
        # Kiểm tra có phím nào được nhấn không
        if msvcrt.kbhit():
            ch = msvcrt.getch()
            if ch in (b'\x00', b'\xe0'):
                ch += msvcrt.getch()  # Nhận thêm byte cho phím đặc biệt
            if not ('''b'\\''' in str (repr (ch))):
                return ch.decode('utf-8', errors='ignore')
            else:
                return str(repr (ch)).split ('b\'')[1].split ('\'')[0]
        else:
            return None  # Không có phím nào được nhấn
    
    else:
        return get_ch_linux()
class button_click:
    def key_up(self):
        return ['\x1b[A','\\xe0H','w','W']
    def key_down(self):
        return ['\x1b[B','\\xe0P','s','S']
    def key_right (self):
        return ['\x1b[C','\\xe0M','d','D']
    def key_left(self):
        return  ['\x1b[D','\\xe0K','a','A']
    def key_enter(self):
        return ["\n",b'\r',b'\n', '\r','', '\\r', '\\n']
class giao_dien_terminal:
    def check_key (self, key_input, key_check=''):
        if (key_input == None):
            return None
        else:
            pass
        if (key_check == 'up'):
            key_check= button_click().key_up()
        elif (key_check == 'down'):
            key_check= button_click().key_down()
        elif (key_check == 'right'):
            key_check= button_click().key_right()
        elif (key_check == 'left'):
            key_check= button_click().key_left()
        elif (key_check == 'enter'):
            key_check= button_click().key_enter()
        elif key_check =='':
            key_check= ''
        if (key_input in key_check):
            return True
        else:
            return False
def load_list_chon(list_chon,clear=True, in_help = True):
    mauu_ngau_nhien = randommau()
    def in_help_ ():
            nonlocal mauu_ngau_nhien
            print (f'{mauu_ngau_nhien}{thanhngang}')
            print ('Vui lòng tắt CAPLOCKS khi nhâp !')
            print ('Nhấn phím "h" để quay menu hướng dẫn')
            print ('Nhấn phím "p" để quay về trang quảng lý')
            print ('Nhấn phím "q" để quay lại/ thoát khỏi nhập')
            print (f'{mauu_ngau_nhien}{thanhngang}')
    while True:
        if (clear):clean_bar()
        stt_demm= len (list_chon) -1
        if (in_help):
            in_help_ ()
        with Live(console=console,  auto_refresh=True) as live:
            while True:
                if (kiemtrathietbi ()):
                    pass
                    # clean_bar ()
                    # in_help_ ()
                    
                display_lines = []
                for dem_stt_in in range(len(list_chon)):
                    if dem_stt_in == stt_demm:
                        display_lines.append( f"[on green]{list_chon[dem_stt_in]['text']}")
                    else:
                        display_lines.append(f"[on default]{list_chon[dem_stt_in]['text']}")
                # Cập nhật Live với nội dung mới
                text = ''
                for t in display_lines:
                    text += f'{t}\n'
                chon_input= getch()
                panel = Panel  (text, width = 80)
                time.sleep (0.03)
                live.update(panel)
                time.sleep (0.03)
                if (giao_dien_terminal().check_key (chon_input, 'down')):
                    stt_demm+=1
                elif (giao_dien_terminal().check_key (chon_input, 'up')):
                    stt_demm-=1
                elif (giao_dien_terminal().check_key (chon_input, 'enter')):
                    break
                elif (chon_input == 'q'):
                    return 'q'
                elif (chon_input == 'p'):
                    return 'p'
                elif (chon_input == 'h'):
                    return 'h'
                if (stt_demm >= len (list_chon) ):
                    stt_demm = 0
                elif (stt_demm <0):
                    stt_demm= len (list_chon) -1
            try:
                lua_chon = list_chon[stt_demm]['chon'].lower()
                return lua_chon
            except:
                print (f'{redb}Lựa chọn không hợp lệ')
