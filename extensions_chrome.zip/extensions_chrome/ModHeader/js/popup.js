import { K as Kt, J as Jt, b as a, I as It, a1 as q, B, G as Gt, N, a as t, M as Mt, O as Ot, H as Ht, R, T } from '../storage-writer-d33f2334.js';
import { J as JN } from '../App-dd002176.js';
import { j as Oe } from '../csp-672ab0f6.js';
import { S as Sd } from '../profile-hook-264bc43e.js';

function u(t){let r;return {c(){r=T("style"),r.textContent="body {\r\n      height: 500px;\r\n      /** Fix FF popup disappearance on long window. */\r\n      width: 620px !important;\r\n    }\r\n\r\n    :root {\r\n      --drawer-width: 36px;\r\n      --app-content-width: calc(100% - 40px);\r\n      --top-bar-width: calc(100% - 35px);\r\n      --top-bar-height: 48px;\r\n    }";},m(t,n){N(t,r,n);},d(t){t&&R(r);}}}function g(t){let r;return {c(){r=T("style"),r.textContent="body {\r\n      height: 100vh;\r\n      width: 100% !important;\r\n    }\r\n    :root {\r\n      --drawer-width: 36px;\r\n      --app-content-width: calc(100% - 40px);\r\n      --top-bar-width: calc(100% - 35px);\r\n      --top-bar-height: 48px;\r\n    }";},m(t,n){N(t,r,n);},d(t){t&&R(r);}}}function b(t$1){let r,n,l,f;r=new JN({});let b=(Oe?g:u)();return {c(){It(r.$$.fragment),n=q(),b.c(),l=B();},m(t,a){Gt(r,t,a),N(t,n,a),b.m(t,a),N(t,l,a),f=!0;},p:t,i(t){f||(Mt(r.$$.fragment,t),f=!0);},o(t){Ot(r.$$.fragment,t),f=!1;},d(t){Ht(r,t),t&&R(n),b.d(t),t&&R(l);}}}Sd();const $=new class extends Kt{constructor(t){super(),Jt(this,t,null,b,a,{});}}({target:document.body});

export { $ as default };
